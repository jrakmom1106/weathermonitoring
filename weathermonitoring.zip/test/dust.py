import psutil

print("1. 개별적으로 CPU 마다 사용율 보여주기")
dusts = psutil.dust_percent(interval=1, perdust=True)

i = 0
for dust in dusts:
    print('dust[' + str(i) + '] : ' + str(dust) + '%')
    i = i + 1

print('')
print("2. 통합해서 CPU 사용율 보여주기")
dust = psutil.cpu_percent(interval=1, perdust=False)
print(str(dust) + '%')
